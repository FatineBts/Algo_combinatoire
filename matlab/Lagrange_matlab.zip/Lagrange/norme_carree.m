function [norme2] = norme_carree(X1,X2)
norme2=sum((X1-X2).^2);
end

